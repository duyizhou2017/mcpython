"""
自动生成 Minecraft 风格的基础贴图
"""
from PIL import Image, ImageDraw
import os, random

def create_texture_folder():
    if not os.path.exists('textures'):
        os.makedirs('textures')

# 定义20种方块的颜色 (R, G, B)
BLOCK_COLORS = {
    'grass': (34, 139, 34),       'dirt': (139, 69, 19),
    'stone': (128, 128, 128),     'sand': (237, 201, 175),
    'water': (30, 144, 255),      'wood': (101, 67, 33),
    'leaves': (0, 100, 0),        'snow': (255, 250, 250),
    'coal_ore': (40, 40, 40),     'iron_ore': (210, 180, 140),
    'gold_ore': (255, 215, 0),    'diamond_ore': (90, 240, 240),
    'brick': (178, 34, 34),       'glass': (200, 220, 255),
    'planks': (180, 130, 80),     'cobblestone': (110, 110, 110),
    'gravel': (130, 130, 130),    'obsidian': (20, 10, 30),
    'clay': (160, 160, 180),      'bedrock': (20, 20, 20),
}

def generate_texture(name, base_color):
    """生成带噪点的简单纹理"""
    size = 64
    img = Image.new('RGB', (size, size), base_color)
    draw = ImageDraw.Draw(img)
    
    # 添加随机噪点模拟真实质感
    for x in range(0, size, 4):
        for y in range(0, size, 4):
            offset = random.randint(-25, 25)
            new_color = tuple(max(0, min(255, c + offset)) for c in base_color)
            draw.rectangle([x, y, x+3, y+3], fill=new_color)
            
    # 添加边框
    draw.rectangle([0, 0, size-1, size-1], outline=(0,0,0), width=1)
    
    path = f'textures/{name}.png'
    img.save(path)

if __name__ == '__main__':
    create_texture_folder()
    random.seed(42) # 保证每次生成的纹理一致
    print("正在生成 20 种基础方块贴图...")
    for name, color in BLOCK_COLORS.items():
        generate_texture(name, color)
    print("✅ 贴图生成完毕！请查看 textures 文件夹。")