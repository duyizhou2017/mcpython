import os
import shutil
from datetime import datetime

def clean_up():
    """Clean up junk files that should not be uploaded to GitHub"""
    print("🧹 Cleaning up project folder...")
    
    # Folders and file types to remove
    junk_dirs = ['__pycache__', '.ursina', 'venv']
    junk_files = ['.log', '.pyc', '.pyo']
    
    cleaned_count = 0
    
    # Walk through the current directory
    for root, dirs, files in os.walk('.'):
        # Remove junk folders
        for d in dirs:
            if d in junk_dirs:
                path = os.path.join(root, d)
                try:
                    shutil.rmtree(path)
                    print(f"   🗑️ Deleted folder: {path}")
                    cleaned_count += 1
                except:
                    pass
        
        # Remove junk files
        for f in files:
            if any(f.endswith(ext) for ext in junk_files):
                path = os.path.join(root, f)
                try:
                    os.remove(path)
                    print(f"   🗑️ Deleted file: {path}")
                    cleaned_count += 1
                except:
                    pass

    if cleaned_count == 0:
        print("   ✨ Folder is already clean!")
    else:
        print(f"   ✅ Cleaned {cleaned_count} items.")

def get_upload_list():
    """List files recommended for upload to GitHub"""
    print("\n📦 Recommended files for GitHub upload:")
    required_files = ['main.py', 'create_textures.py', 'README.md']
    
    for file in required_files:
        if os.path.exists(file):
            print(f"   ✅ {file}")
        else:
            print(f"   ⚠️ {file} (Missing)")
            
    if os.path.exists('textures'):
        print(f"   ✅ textures/ folder")
    else:
        print(f"   ⚠️ textures/ folder (Missing)")

def log_runtime_errors():
    """Check for recent game crash logs"""
    log_files = [f for f in os.listdir('.') if f.endswith('.log')]
    if log_files:
        print(f"\n⚠️ Found {len(log_files)} error log file(s). Consider uploading them for debugging:")
        for lf in log_files:
            print(f"   📄 {lf}")

def main():
    print("="*40)
    print("🚀 GitHub Web Upload Assistant")
    print("="*40)
    
    # 1. Clean up junk
    clean_up()
    
    # 2. Show upload list
    get_upload_list()
    
    # 3. Check for error logs
    log_runtime_errors()
    
    print("\n" + "="*40)
    print("💡 Next Steps:")
    print("1. Open browser: https://github.com/duyizhou2017/mcpython")
    print("2. Click 'Add file' -> 'Upload files'")
    print("3. Drag the files listed above into the browser!")
    print("="*40)

if __name__ == "__main__":
    main()
