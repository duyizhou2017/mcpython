from ursina import *

app = Ursina()
# 创建一个红色的方块
box = Entity(model='cube', color=color.red, position=(0, 0, 5))
# 添加光源
light = DirectionalLight()
light.look_at(Vec3(1, -1, -1))

print("✅ 如果你能看到一个红色方块，说明环境完全正常！")
app.run()