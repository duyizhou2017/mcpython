from ursina import *
from perlin_noise import PerlinNoise
import random

app = Ursina()
window.color = color.rgb(135, 206, 235)

# ================= 1. 基础配置 =================
BLOCKS = {
    1: {'name': 'grass', 'color': color.green}, 2: {'name': 'dirt', 'color': color.brown},
    3: {'name': 'stone', 'color': color.gray}, 4: {'name': 'sand', 'color': color.yellow},
    5: {'name': 'water', 'color': color.blue}, 6: {'name': 'wood', 'color': color.rgb(101, 67, 33)},
    7: {'name': 'leaves', 'color': color.rgb(0, 100, 0)}, 8: {'name': 'snow', 'color': color.white},
    9: {'name': 'coal_ore', 'color': color.black}, 10: {'name': 'iron_ore', 'color': color.rgb(210, 180, 140)},
    11: {'name': 'gold_ore', 'color': color.gold}, 12: {'name': 'diamond_ore', 'color': color.cyan},
    13: {'name': 'brick', 'color': color.red}, 14: {'name': 'glass', 'color': color.rgba(200, 220, 255, 150)},
    15: {'name': 'planks', 'color': color.rgb(180, 130, 80)}, 16: {'name': 'cobblestone', 'color': color.gray},
    17: {'name': 'gravel', 'color': color.rgb(130, 130, 130)}, 18: {'name': 'obsidian', 'color': color.rgb(20, 10, 30)},
    19: {'name': 'clay', 'color': color.rgb(160, 160, 180)}, 20: {'name': 'bedrock', 'color': color.black},
}

# ================= 2. 高效方块类 (非 Button) =================
class Voxel(Entity):
    def __init__(self, position=(0,0,0), block_id=1):
        super().__init__(
            parent=scene,
            position=position,
            model='cube',
            origin_y=0.5,
            texture=f'textures/{BLOCKS[block_id]["name"]}.png',
            color=BLOCKS[block_id]['color'],
            collider='box' # 必须有碰撞体才能被射线检测到
        )

# ================= 3. 地形生成器 =================
class TerrainGenerator:
    def __init__(self):
        self.chunk_size = 16
        self.noise = PerlinNoise(octaves=3, seed=random.randint(0, 10000))
        
    def get_height(self, x, z):
        return int((self.noise([x*0.05, z*0.05]) + 1) * 5) + 2

    def get_block_id(self, y, h):
        if y > h: return None
        if y == h: return 5 if h < 4 else (4 if h < 5 else 1)
        if y > h - 3: return 2
        if y < 1: return 20
        return 3

    def generate_area(self, radius=2):
        """生成指定半径内的地形"""
        print(f"正在生成半径 {radius} 的地形...")
        for x in range(-radius, radius + 1):
            for z in range(-radius, radius + 1):
                h = self.get_height(x, z)
                for y in range(h + 1):
                    bid = self.get_block_id(y, h)
                    if bid: Voxel((x, y, z), block_id=bid)
        print("✅ 生成完毕！")

# ================= 4. 玩家控制器 =================
class Player(Entity):
    def __init__(self):
        super().__init__()
        camera.parent = self
        camera.position = (0, 1.6, 0)
        camera.fov = 50 # 窄视野
        mouse.locked = True
        self.speed = 6
        self.gravity = 25
        self.vel = Vec3(0, 0, 0)

    def update(self):
        # 移动
        dir = Vec3(0, 0, 0)
        if held_keys['w']: dir += self.forward
        if held_keys['s']: dir -= self.forward
        if held_keys['a']: dir -= self.right
        if held_keys['d']: dir += self.right
        if dir.length() > 0:
            dir.y = 0
            self.position += dir.normalized() * self.speed * time.dt

        # 重力
        self.vel.y -= self.gravity * time.dt
        self.position.y += self.vel.y * time.dt
        if self.position.y < 0:
            self.position.y = 0
            self.vel.y = 0

        # 视角
        self.rotation_y -= mouse.velocity[0] * 100
        camera.rotation_x = clamp(camera.rotation_x - mouse.velocity[1] * 100, -90, 90)

        # 交互 (破坏/放置)
        if mouse.left or mouse.right:
            hit = raycast(camera.world_position, camera.forward, distance=5)
            if hit.hit:
                if mouse.left: 
                    destroy(hit.entity)
                elif mouse.right: 
                    Voxel(hit.entity.position + hit.normal, block_id=1)

# ================= 5. 启动 =================
terrain = TerrainGenerator()
terrain.generate_area(radius=2) # 只生成 5x5 的区域，非常快
player = Player()

app.run()
