from ursina import *

app = Ursina()
window.color = color.rgb(135, 206, 235) # 天空蓝

# 简单的方块类
class Voxel(Button):
    def __init__(self, position=(0,0,0)):
        super().__init__(
            parent=scene,
            position=position,
            model='cube',
            origin_y=0.5,
            texture='white_cube', # 使用引擎自带的白色方块纹理，不需要外部图片
            color=color.green,
            highlight_color=color.lime,
        )

    def input(self, key):
        if self.hovered:
            if key == 'left mouse down': destroy(self)
            elif key == 'right mouse down': Voxel(position=self.position + mouse.normal)

# 快速生成一个小平台 (5x5)
print("正在快速生成地面...")
for x in range(-2, 3):
    for z in range(-2, 3):
        Voxel(position=(x, 0, z))
print("✅ 完成！")

# 玩家
player = Entity()
camera.parent = player
camera.position = (0, 1.6, 0)
mouse.locked = True

def update():
    speed = 5
    if held_keys['w']: player.position += player.forward * speed * time.dt
    if held_keys['s']: player.position -= player.forward * speed * time.dt
    if held_keys['a']: player.position -= player.right * speed * time.dt
    if held_keys['d']: player.position += player.right * speed * time.dt
    
    # 简单的视角控制
    player.rotation_y -= mouse.velocity[0] * 100
    camera.rotation_x -= mouse.velocity[1] * 100
    camera.rotation_x = clamp(camera.rotation_x, -90, 90)

app.run()
